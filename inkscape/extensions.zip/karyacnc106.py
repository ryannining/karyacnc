#!/usr/bin/python
import os
import sys
import time
tl=0
fn="/home/ryan/output.gcode"
#karyacnc="ws://localhost:8888"
#karyacnc="ws://localhost:8889"
karyacnc="ws://192.168.0.106:8888"
#karyacnc="ws://localhost:8888"

while 1:
	t=os.stat(fn).st_mtime
	if (t<>tl):
		tl=t
		f = open(fn, "r")
		gcode=f.read()
		f.close()
		from websocket import create_connection
		print "connecting...",karyacnc
		ws = create_connection(karyacnc)
		print "connected."
		for g in gcode.split("\n"):
			ws.send(g)
			ws.send("\n")
		ws.send(">REVECTOR")
		ws.close()
		print "done..."
	time.sleep(1)
